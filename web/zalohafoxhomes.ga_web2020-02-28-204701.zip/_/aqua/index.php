<link rel="stylesheet" type="text/css" href="stylesheet.css">
<html>
    <body>
    <div >
        
        <img src="/_/aqua/image/aqua.jpg" class="center" > 
    </div>
    
    
    </body>
    
    
</html>